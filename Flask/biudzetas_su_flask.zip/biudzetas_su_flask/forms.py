from flask_wtf import FlaskForm
from wtforms import (
    StringField, 
    SubmitField, 
    FloatField
    )
    
from wtforms.validators import DataRequired


class PajamosForm(FlaskForm):
    siuntejas = StringField('Siuntėjas', [DataRequired()])
    papildoma_info = StringField('Papildoma Info', [DataRequired()])
    suma = FloatField("Suma", [DataRequired()])
    submit = SubmitField('Įvesti')


class IslaidosForm(FlaskForm):
    atsiskaitymo_budas = StringField("Atsiskaitymo būdas", [DataRequired()])
    isigyta_preke = StringField("Įsigyta prekė/paslauga", [DataRequired()])
    suma = FloatField("Suma", [DataRequired()])
    submit = SubmitField('Įvesti')

