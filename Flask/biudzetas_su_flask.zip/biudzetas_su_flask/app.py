from flask import Flask, render_template, redirect, url_for
from forms import PajamosForm, IslaidosForm
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import os 

basedir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
key = 'blablablaverysecure'

app.config['SECRET_KEY'] = key
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'data.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
Migrate(app, db)


class Pajamos(db.Model):
    __tablename__ = 'pajamos'
    id = db.Column(db.Integer, primary_key=True)
    siuntejas = db.Column(db.String(200), nullable=False)
    papildoma_info = db.Column(db.String(500))
    suma = db.Column(db.Float, nullable=False)

    def __init__(self, siuntejas, papildoma_info, suma):
        self.siuntejas = siuntejas
        self.papildoma_info = papildoma_info
        self.suma = suma

    def __repr__(self):
        return f'{self.suma} - {self.siuntejas}'


class Islaidos(db.Model):
    __tablename__ = 'islaidos'
    id = db.Column(db.Integer, primary_key=True)
    atsiskaitymo_budas = db.Column(db.String(200))
    preke_paslauga = db.Column(db.String(200), nullable=False)
    suma = db.Column(db.Float, nullable=False)

    def __init__(self, atsiskaitymo_budas, preke_paslauga, suma):
        self.atsiskaitymo_budas = atsiskaitymo_budas
        self.preke_paslauga = preke_paslauga
        self.suma = suma

    def __repr__(self):
        return f'{self.suma} - {self.preke_paslauga}'

@app.route('/')
def home():
    visos_pajamos = Pajamos.query.all()
    visos_islaidos = Islaidos.query.all()
    balance_list = []
    for pajamos in visos_pajamos:
        balance_list.append(pajamos.suma)
    for islaidos in visos_islaidos:
        balance_list.append(-islaidos.suma)
    balansas = sum(balance_list)

    return render_template(
        'index.html',
        pajamos = visos_pajamos, 
        islaidos=visos_islaidos, 
        balansas=balansas
        )

@app.route('/pajamos', methods=['GET', 'POST'])
def pajamos():
    form = PajamosForm()
    print('iki validacijos')
    if form.validate_on_submit():
        print()
        naujos_pajamos = Pajamos(
            siuntejas=form.siuntejas.data,
            papildoma_info = form.papildoma_info.data,
            suma = float(form.suma.data)
        )
        db.session.add(naujos_pajamos)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('pajamos.html', form=form)

@app.route('/islaidos', methods=['GET', 'POST'])
def islaidos():
    form = IslaidosForm()
    if form.validate_on_submit():
        naujos_islaidos = Islaidos(
            atsiskaitymo_budas=form.atsiskaitymo_budas.data,
            preke_paslauga=form.isigyta_preke.data,
            suma=float(form.suma.data)
        )
        db.session.add(naujos_islaidos)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('islaidos.html', form=form)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)



