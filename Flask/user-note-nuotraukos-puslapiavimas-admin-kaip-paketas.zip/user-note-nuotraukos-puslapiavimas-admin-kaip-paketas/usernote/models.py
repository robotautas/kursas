from usernote import db
from datetime import datetime
from flask_login import UserMixin

class User(db.Model, UserMixin):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column("user_name", db.String(50), unique=True, nullable=False)
    email = db.Column("email", db.String(120), unique=True, nullable=False)
    picture = db.Column(db.String(20), nullable=True, default='default.jpg')
    password = db.Column("password", db.String(60), unique=True, nullable=False)
    notes = db.relationship("Note", back_populates='user')


class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    body = db.Column('body', db.String(500))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    user = db.relationship("User", back_populates='notes')