import requests

class IPWeather:
    WEATHER_CODES = {
        "Clear sky": (0, ),
        "Mainly clear, partly cloudy, and overcast": (1, 2, 3),
        "Fog and depositing rime fog": (45, 48),
        "Drizzle: Light, moderate, and dense intensity": (51, 53, 55),
        "Freezing Drizzle: Light and dense intensity": (56, 57),
        "Rain: Slight, moderate and heavy intensity": (61, 63, 65),
        "Freezing Rain: Light and heavy intensity": (66, 67),
        "Snow fall: Slight, moderate, and heavy intensity": (71, 73, 75),
        "Snow grains": (77, ),
        "Rain showers: Slight, moderate, and violent": (80, 81, 82),
        "Snow showers slight and heavy": (85, 86), 
        "Thunderstorm: Slight or moderate": (95, ),
        "Thunderstorm with slight and heavy hail": (96, 99)
    }

    def __init__(self, ip):
        self.ip = ip

    def get_weather_by_code(self, code):
        for k, v in self.WEATHER_CODES.items():
            for digit in v:
                if digit == code:
                    return k
        raise ValueError('Inappropriate weather code provided, please check API docs!')

    def ip_location(self):
        values = {}
        response = requests.get(f'https://ipapi.co/{self.ip}/json/').json()
        values['ip'] = response['ip']
        values['country'] = response['country_name']
        values['city'] = response['city']
        values['lat'] = response['latitude']
        values['lon'] = response['longitude']
        return values

    def location_weather(self, lat, lon):
        values = {}
        response = requests.get(f'https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true&current_weather=true').\
            json()['current_weather']  
        values['temperature'] = response["temperature"]
        values['weather'] = self.get_weather_by_code(response['weathercode'])
        return values

    def weather(self):
        loc_values = self.ip_location()
        lat = loc_values['lat']
        lon = loc_values['lon']
        weather_values = self.location_weather(lat=lat, lon=lon)
        del loc_values['lat']
        del loc_values['lon']
        combined_values = loc_values
        for k, v in weather_values.items():
            combined_values[k] = v
        return combined_values








