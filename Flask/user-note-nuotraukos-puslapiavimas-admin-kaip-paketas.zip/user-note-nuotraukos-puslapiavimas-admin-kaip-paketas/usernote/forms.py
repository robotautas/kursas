from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import SubmitField, BooleanField, StringField, PasswordField, TextAreaField
from wtforms.validators import DataRequired, ValidationError, EqualTo
from flask_login import current_user
from .models import User

class SignUpForm(FlaskForm):
    name = StringField('Name', [DataRequired()])
    email = StringField('Email', [DataRequired()])
    password = PasswordField('Password', [DataRequired()])
    repeat_password = PasswordField('Repeat Password', [EqualTo('password', "Passwords must match")])
    submit = SubmitField('Sign in')

    def validate_name(self, name):
        user = User.query.filter_by(name=name.data).first()
        if user:
            raise ValidationError("Username taken!")

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError("Username taken!")


class LogInForm(FlaskForm):
    email = StringField('Email', [DataRequired()])
    password = PasswordField('Password', [DataRequired()])
    remember = BooleanField("Remember me")
    submit = SubmitField('Login')


class AccountEditForm(FlaskForm):
    name = StringField('Name', [DataRequired()])
    email = StringField('Email', [DataRequired()])
    picture = FileField('Add/change profile picture', validators=[FileAllowed(['jpg', 'png'])])
    submit = SubmitField('Submit')

    def validate_name(self, name):
        if name.data != current_user.name:
            user = User.query.filter_by(name=name.data).first()
            if user:
                raise ValidationError('Username taken, please choose another.')

    def validate_email(self, email):
        if email.data != current_user.email:
            user = User.query.filter_by(name=email.data).first()
            if user:
                raise ValidationError('Email already exists, please choose another.')

class NoteForm(FlaskForm):
    body = TextAreaField('Note', [DataRequired()])
    submit = SubmitField('Submit')

class WeatherForm(FlaskForm):
    ip = StringField('IP', [DataRequired()])
    submit = SubmitField('Submit')