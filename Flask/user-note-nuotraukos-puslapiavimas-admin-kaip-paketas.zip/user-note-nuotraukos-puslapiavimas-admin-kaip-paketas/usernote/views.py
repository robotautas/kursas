from flask import render_template, redirect, flash, url_for, request
from flask_login import current_user, login_user, logout_user, login_required
from usernote import app, db, bcrypt
from .models import User, Note
from .forms import LogInForm, SignUpForm, NoteForm, AccountEditForm, WeatherForm
from .weather import IPWeather

import os
import secrets
from PIL import Image


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/sign_up', methods=['GET', 'POST'])
def sign_up():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = SignUpForm()
    if form.validate_on_submit():
        encrypted_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(name=form.name.data, email=form.email.data, password=encrypted_password)
        db.session.add(user)
        db.session.commit()
        flash('Registration complete! You can sign up now!', 'info')
        return redirect(url_for('home'))
    return render_template('signup.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        print('is_auth!!!!')
        return redirect(url_for('home'))
    form = LogInForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash("Wrong email/password!", 'danger')
    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('home'))

def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(app.root_path, 'static/account_pictures', picture_fn)

    output_size = (125, 125)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)

    return picture_fn


@app.route("/account", methods=['GET', 'POST'])
@login_required
def account():
    form = AccountEditForm()
    if form.validate_on_submit():
        if form.picture.data:
            picture = save_picture(form.picture.data)
            current_user.picture = picture
        current_user.name = form.name.data
        current_user.email = form.email.data
        db.session.commit()
        flash('Successfully updated!', 'success')
        return redirect(url_for('account'))
    elif request.method == 'GET':
        form.name.data = current_user.name
        form.email.data = current_user.email
    picture = url_for('static', filename='account_pictures/' + current_user.picture)
    return render_template('account.html', title='Account', form=form, picture=picture)

@app.route('/notes', methods=['GET', 'POST'])
@login_required
def notes():
    form = NoteForm()
    if form.validate_on_submit():
        note = Note(
            body=form.body.data,
            user=current_user
            )
        db.session.add(note)
        db.session.commit()
    page = request.args.get('page', 1, type=int)
    notes = Note.query.filter_by(user=current_user).order_by(Note.date.desc()).paginate(page=page, per_page=5)
    return render_template("notes.html", form=form, notes=notes)

@app.route('/weather', methods=['GET', 'POST'])
def weather_ip():
    weather = None
    form = WeatherForm()
    if form.validate_on_submit():
        forecaster = IPWeather(form.ip.data)
        weather = forecaster.weather()
    return render_template('weather.html', form=form, weather=weather)