from flask_admin.contrib.sqla import ModelView
from usernote import app, db, admin, login_manager, ManoModelView
from usernote.models import User, Note
from usernote.views import sign_up, login, logout, account, weather_ip, home, notes

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

admin.add_view(ModelView(Note, db.session))
admin.add_view(ManoModelView(User, db.session))

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)
