import os
from flask import Flask, render_template, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
import forms
from flask_migrate import Migrate

basedir = os.path.abspath(os.path.dirname(__file__))
print(basedir)

app = Flask(__name__)

app.config['SECRET_KEY'] = 'dfgsfdgsdfgsdfgsdf'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'testai.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

Migrate(app, db)

class Klausimas(db.Model):
    __tablename__ = "klausimas"
    id = db.Column(db.Integer, primary_key=True)
    klausimas = db.Column("Klausimas", db.String)
    pirmas_atsakymas = db.Column("1 atsakymas", db.String)
    antras_atsakymas = db.Column("2 atsakymas", db.String)
    trecias_atsakymas = db.Column("3 atsakymas", db.String)
    teisingas = db.Column("Teisingas atsakymas", db.Integer)

# Šitas (kol kas) nieko nedaro
class Atsakymas(db.Model):
    __tablename__ = "atsakymas"
    id = db.Column(db.Integer, primary_key=True)
    klausimo_id = db.Column("Klausimo ID", db.Integer)
    atsakymas = db.Column("Atsakymas", db.Integer)

class Rezultatas(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rezultatas = db.Column('rezultatas', db.Integer)

# pagalbinės funkcijos, kad maršrutas būtų skaitomesnis 
def papildyti_rezultata():
    res = Rezultatas.query.get(1)
    res.rezultatas += 1
    db.session.commit()

# kai pasiimame rezultatą tuo pačiu ir nunulinam
def gauti_rezultata():
    res = Rezultatas.query.get(1)
    atsakymas = res.rezultatas
    res.rezultatas = 0
    db.session.commit()
    return atsakymas

# pirmam paleidimui
if not Rezultatas.query.get(1):
    res = Rezultatas(rezultatas=0)
    print('sukurta rezultato eilutė!')
    db.session.add(res)
    db.session.commit()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/klausimai")
def klausimai():
    visi_klausimai = Klausimas.query.all()
    return render_template("klausimai.html", visi_klausimai=visi_klausimai)

@app.route("/naujas_klausimas", methods=["GET", "POST"])
def naujas_klausimas():
    forma = forms.KlausimasForm()
    if forma.validate_on_submit():
        naujas_klausimas = Klausimas(
            klausimas=forma.klausimas.data, 
            pirmas_atsakymas=forma.pirmas_atsakymas.data, 
            antras_atsakymas=forma.antras_atsakymas.data, 
            trecias_atsakymas=forma.trecias_atsakymas.data,
            teisingas=forma.teisingas_atsakymas.data
            )
        db.session.add(naujas_klausimas)
        db.session.commit()
        return redirect(url_for('klausimai'))
    return render_template("prideti_klausima.html", form=forma)

@app.route("/testas")
@app.route("/testas/<int:klausimo_id>", methods=["GET", "POST"])
def testas(klausimo_id=1):
    forma = forms.TestasForm()
    aktyvus_klausimas = Klausimas.query.get(klausimo_id)
    if forma.validate_on_submit():
        if aktyvus_klausimas.teisingas == int(forma.pasirinktas_atsakymas.data): papildyti_rezultata()
        klausimo_id +=1 # šitas iš atminties nedingsta, kaskartą inicijuojant f-ją ji kreipiasi į tą patį adresą atmintyje.
    if klausimo_id <= len(Klausimas.query.all()):
        return render_template("testas.html", form=forma, aktyvus_klausimas=Klausimas.query.get(klausimo_id))
    else:
        return render_template('rezultatas.html', rezultatas=gauti_rezultata(), klausimu_skaicius=len(Klausimas.query.all()))
    return render_template("testas.html", form=forma, aktyvus_klausimas=aktyvus_klausimas)

@app.route("/istrinti_klausima/<int:id>")
def istrinti_klausima(id):
    uzklausa = Klausimas.query.get(id)
    db.session.delete(uzklausa)
    db.session.commit()
    return redirect(url_for('klausimai'))

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)
    db.create_all()