from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, RadioField
from wtforms.validators import DataRequired


class KlausimasForm(FlaskForm):
    klausimas = StringField('Klausimas', [DataRequired()])
    pirmas_atsakymas = StringField('1 atsakymas', [DataRequired()])
    antras_atsakymas = StringField('2 atsakymas', [DataRequired()])
    trecias_atsakymas = StringField('3 atsakymas', [DataRequired()])
    teisingas_atsakymas = RadioField(
        'Teisingas atsakymas:', 
        choices=[('1', 1), ('2', 2), ('3', 3)], 
        validators=[DataRequired('Pamiršote pažymėti teisingą atsakymą!')])
    submit = SubmitField('Įvesti')


class TestasForm(FlaskForm):
    pasirinktas_atsakymas = RadioField(
        'Jūsų atsakymas: ', 
        choices=[('1', 1), ('2', 2), ('3', 3)], 
        validators=[DataRequired('Pamiršote pažymėti teisingą atsakymą!')])
    submit = SubmitField('Kitas klausimas')
